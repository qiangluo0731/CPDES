function [gd, spread] = RLMA_metrics(population, objectiveScale, reference)
%RLMA_METRICS Compute GD and Spread according to manuscript Eqs. (42)-(43).
%
% Smaller values are better for both indicators:
%   GD     -> convergence quality;
%   Spread -> distribution uniformity.
%
% objectiveScale is retained in the interface for backward compatibility.
% The current manuscript formulas are evaluated directly from objective
% values without additional scaling inside this function.

%#ok<INUSD>
obj = reshape([population.objectives],3,[])';
[rank,~] = RLMA_rank(obj);
pf = unique(obj(rank==1,:),'rows','stable');

if isempty(pf)
    gd = Inf;
    spread = Inf;
    return;
end

ref = reference(:)';

% Eq. (42): GD(P,P*) for the predefined reference point/set.
dist = sqrt(sum(bsxfun(@minus,pf,ref).^2,2));
gd = sqrt(sum(dist.^2))/size(pf,1);

% Eq. (43): Spread based on distances between adjacent PF solutions.
if size(pf,1) < 2
    spread = 0;
    return;
end

pf = sortrows(pf,[1,2,3]);
d = sqrt(sum(diff(pf,1,1).^2,2));
dbar = mean(d);

if dbar <= eps
    spread = 0;
else
    spread = sum(abs(d-dbar))/(numel(d)*dbar);
end
end
