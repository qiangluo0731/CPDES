function [selected, frontNo, crowding] = RLMA_environmental(candidates, popSize, data, opts)
%RLMA_ENVIRONMENTAL Elitist nondominated sorting + crowding selection.
% Duplicate objective vectors are removed before selection; shortage is
% filled with new random feasible chromosomes, per manuscript Sec. 4.4.
if isempty(candidates)
    candidates = repmat(RLMA_random_individual(data),1,popSize);
    for i=1:popSize
        candidates(i)=RLMA_random_individual(data);
    end
end
candidates = decode_pop(candidates,data,opts);
obj = reshape([candidates.objectives],3,[])';
assert(all(isfinite(obj(:))), 'Environmental selection received nonfinite objective.');
[~,uniqueIdx] = unique(obj,'rows','stable');
candidates = candidates(sort(uniqueIdx));

if numel(candidates)<popSize
    missing=popSize-numel(candidates);
    for i=1:missing
        candidates(end+1) = RLMA_random_individual(data); %#ok<AGROW>
    end
    candidates=decode_pop(candidates,data,opts);
end
obj = reshape([candidates.objectives],3,[])';
[rank,crowd] = RLMA_rank(obj);
[~,ordering] = sortrows([rank(:),-crowd(:),(1:numel(rank))'],[1,2,3]);
chosen = ordering(1:min(popSize,numel(ordering)));
selected = candidates(chosen);
frontNo = rank(chosen)';
crowding = crowd(chosen)';
end
