function utility = OU_adjust(decode_trans, due_multi_p, V_p, V_de)
%OU_ADJUST Maximum equipment-operation utility (manuscript Section 3.2).
%   utility = OU_adjust(decode_trans, failureTimes, efficiency, degradation)
%
%   decode_trans: 7-by-N; row 1 job IDs, row 6 delivery times.
%   due_multi_p: N-by-G failure times in order fastest -> slowest,
%                increasing strictly across columns.
%   V_p:         N-by-G throughput/operating efficiency (fastest -> slowest).
%   V_de:        N-by-G degradation rates (retained for legacy API).
%
%   utility is 3-by-N, indexed by JOB ID:
%   row 1 utility = actual capacity / (fastest efficiency * fastest failure time)
%   row 2 strategy code (a*10+b for switching a->b; a for constant speed)
%   row 3 switching time (0 when there is no switch).
%
%   The three manuscript cases are handled analytically, including equality
%   boundaries. For G>2, feasible single-switch speed pairs are compared.
%   No artificial clipping to [0,1] is performed: the paper's denominator can
%   be smaller than capacity output under a slow-speed lifetime extension.
%
%   V_de is validated for consistency but the analytic formula uses the known
%   failure times already derived from the degradation parameters.
if nargin<4
    error('OU_adjust requires four inputs.');
end
n = size(due_multi_p,1);
g = size(due_multi_p,2);
assert(size(decode_trans,1)>=6 && size(decode_trans,2)==n, 'Invalid decode_trans.');
assert(isequal(size(V_p),[n,g]) && isequal(size(V_de),[n,g]), 'Speed arrays mismatch.');
assert(all(due_multi_p(:)>0) && all(V_p(:)>0) && all(V_de(:)>0), 'Positive equipment parameters required.');
assert(all(all(diff(due_multi_p,1,2)>0)), 'Failure times must increase with slower speed.');
assert(all(all(diff(V_p,1,2)<0)), 'Speed efficiency must decrease across columns.');

jobID = decode_trans(1,:);
assert(isequal(sort(jobID),1:n), 'Transport schedule must contain each job exactly once.');
delivery = zeros(1,n);
delivery(jobID) = decode_trans(6,:);
assert(all(isfinite(delivery)) && all(delivery>=0), 'Invalid delivery times.');

utility = zeros(3,n);
tol = 1e-10;
for i=1:n
    d = delivery(i);
    t = due_multi_p(i,:);
    e = V_p(i,:);
    idealCapacity = e(1)*t(1);
    if d<=t(1)+tol
        utility(:,i) = [1;1;0];
        continue;
    end
    if d>=t(end)-tol
        utility(:,i) = [e(end)*t(end)/idealCapacity;g;0];
        continue;
    end

    % Feasible single-speed schedules and high->low one-switch schedules.
    bestOutput = -Inf;
    bestCode = 0;
    bestSwitch = 0;
    for slow=1:g
        if d<=t(slow)+tol
            capacity = e(slow)*d;
            if capacity>bestOutput
                bestOutput = capacity;
                bestCode = slow;
                bestSwitch = 0;
            end
        end
    end
    for fast=1:g-1
        for slow=fast+1:g
            if d<t(fast)-tol || d>t(slow)+tol
                continue;
            end
            switchTime = t(fast)*(t(slow)-d)/(t(slow)-t(fast));
            if switchTime < -tol || switchTime > d+tol
                continue;
            end
            switchTime = max(0,min(d,switchTime));
            capacity = switchTime*e(fast)+(d-switchTime)*e(slow);
            if capacity>bestOutput
                bestOutput = capacity;
                bestCode = 10*fast+slow;
                bestSwitch = switchTime;
            end
        end
    end
    assert(isfinite(bestOutput) && bestOutput>0, 'No feasible equipment speed strategy for job %d.',i);
    utility(:,i)=[bestOutput/idealCapacity;bestCode;bestSwitch];
end
end
