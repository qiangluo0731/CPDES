function data = RLMA_load_instance(instanceFile)
%RLMA_LOAD_INSTANCE Load and validate the CPDES .mat benchmark format.
% Required MAT variables: job_set, manufacturer_set, servicer_set.
raw = load(instanceFile);
required = {'job_set','manufacturer_set','servicer_set'};
for k = 1:numel(required)
    assert(isfield(raw,required{k}), 'Missing benchmark variable: %s',required{k});
end
job_set = raw.job_set;
manufacturer_set = raw.manufacturer_set;
servicer_set = raw.servicer_set;
assert(iscell(job_set) && numel(job_set)>=6, 'Invalid job_set cell array.');
assert(iscell(manufacturer_set) && numel(manufacturer_set)>=4, 'Invalid manufacturer_set.');
assert(iscell(servicer_set) && numel(servicer_set)>=4, 'Invalid servicer_set.');

data.jobCount = double(job_set{1}(1));
data.stageCount = double(job_set{1}(2));
data.shopCount = double(manufacturer_set{2});
data.timeSet = manufacturer_set{3};
data.energySet = manufacturer_set{4};
data.jobWeights = double(job_set{3}(:)');
data.speedEfficiency = double(job_set{4});
data.degradationRates = double(job_set{5});
data.failureTimes = double(job_set{6});
data.vehicleCount = size(servicer_set{2},2);
data.vehicleSpeed = double(servicer_set{2});
data.vehicleEnergyRate = double(servicer_set{3});
data.vehicleCapacity = double(servicer_set{4}(:)');

n = data.jobCount;
assert(data.stageCount>=1 && data.shopCount>=1 && data.vehicleCount>=1, 'Invalid dimensions.');
assert(numel(data.jobWeights)==n, 'Job weights must have N entries.');
assert(all(data.jobWeights>0), 'Job weights must be positive.');
assert(iscell(data.timeSet) && numel(data.timeSet)==data.shopCount, 'Invalid shop time tables.');
assert(iscell(data.energySet) && numel(data.energySet)==data.shopCount, 'Invalid energy tables.');
for s=1:data.shopCount
    assert(isequal(size(data.timeSet{s}),[n,data.stageCount]), 'Processing times dimension mismatch.');
    assert(isequal(size(data.energySet{s}),[2,data.stageCount]), 'Energy rates must be 2-by-M.');
    assert(all(data.timeSet{s}(:)>=0) && all(data.energySet{s}(:)>=0), 'Negative shop time/energy rate.');
end
assert(isequal(size(data.vehicleSpeed),[2,data.vehicleCount]), 'Vehicle speed must be 2-by-V.');
assert(isequal(size(data.vehicleEnergyRate),[2,data.vehicleCount]), 'Vehicle energy rate must be 2-by-V.');
assert(all(data.vehicleSpeed(:)>0) && all(data.vehicleEnergyRate(:)>=0), 'Invalid vehicle rates.');
assert(numel(data.vehicleCapacity)==data.vehicleCount && all(data.vehicleCapacity>0), 'Invalid capacities.');
assert(all(data.jobWeights <= max(data.vehicleCapacity)+1e-10), 'A job is heavier than every vehicle.');
assert(size(data.speedEfficiency,1)==n && isequal(size(data.speedEfficiency),size(data.failureTimes)), 'Equipment tables mismatch.');
assert(all(data.speedEfficiency(:)>0) && all(data.failureTimes(:)>0), 'Invalid equipment data.');
assert(all(all(diff(data.failureTimes,1,2)>0)), 'Failure times must increase as speeds decrease.');
assert(isequal(size(data.degradationRates),size(data.speedEfficiency)), 'Degradation rates dimension mismatch.');

origin = double(manufacturer_set{1}(:));
customers = double(job_set{2});
assert(size(customers,1)==numel(origin) && size(customers,2)==n, 'Customer coordinates mismatch.');
delta = bsxfun(@minus,customers,origin);
data.depotDistance = sqrt(sum(delta.^2,1));
data.customerDistance = zeros(n,n);
for i=1:n
    d = bsxfun(@minus,customers,customers(:,i));
    data.customerDistance(i,:) = sqrt(sum(d.^2,1));
end
[~,data.name] = fileparts(instanceFile);
end
