function state = RLMA_state(deltaGD, deltaSpread)
%RLMA_STATE Map changes in GD and Spread to the four manuscript states.
%
% Both GD and Spread are minimization-type performance indicators:
%   deltaGD     < 0 : convergence improves;
%   deltaSpread < 0 : distribution uniformity improves.
%
% State definition used in the revised manuscript:
%   s1: deltaGD < 0  && deltaSpread < 0   (both improve)
%   s2: deltaGD < 0  && deltaSpread >= 0  (only convergence improves)
%   s3: deltaGD >= 0 && deltaSpread < 0   (only distribution improves)
%   s4: deltaGD >= 0 && deltaSpread >= 0  (neither improves)

if deltaGD < 0
    if deltaSpread < 0
        state = 1;
    else
        state = 2;
    end
else
    if deltaSpread < 0
        state = 3;
    else
        state = 4;
    end
end
end
