function [improved, accepted] = RLMA_local_search(parent, method, data, opts)
%RLMA_LOCAL_SEARCH Manuscript Algorithms 1-3 (Mf1/Mf2/Mf3).
% 1: move most-delayed job to energy-cheapest shop; try insertion positions.
% 2: transfer a job from the most-loaded shop to least-loaded shops.
% 3: swap most-delayed job's priority with same-shop jobs.
% A candidate replaces its parent only when it Pareto-dominates the parent.
improved=parent;
accepted=false;
n=data.jobCount;
S=data.shopCount;
assert(all(size(parent.decode_transport)==[7,n]), 'Parent must be decoded.');
lastDelivery=zeros(1,n);
lastDelivery(parent.decode_transport(1,:))=parent.decode_transport(6,:);
% Manuscript rs = delivery_time - due_date_set. With multiple thresholds,
% use the first (fast-speed failure bound) as the urgency baseline.
lateness=lastDelivery-data.failureTimes(:,1)';
orders=parent.shop_orders;
shops=parent.shop_assignment;
switch method
    case 1 % Mf1: minimize processing energy of the selected urgent job.
        [~,job]=max(lateness);
        energyCost=zeros(1,S);
        for s=1:S
            energyCost(s)=sum(data.timeSet{s}(job,:).*data.energySet{s}(1,:));
        end
        [~,target]=min(energyCost);
        shortened=remove_from_orders(orders,job);
        for pos=numel(shortened{target})+1:-1:1
            trialOrder=shortened;
            trialOrder{target}=insert_at(trialOrder{target},job,pos);
            candidate=evaluate_orders(parent,trialOrder,data,opts);
            if dominates(candidate.objectives,parent.objectives)
                improved=candidate; accepted=true; return;
            end
        end
    case 2 % Mf2: rebalance maximum-workload workshop.
        [~,heaviest]=max(parent.shop_load);
        candidates=find(shops==heaviest);
        if isempty(candidates) || S<2, return; end
        [~,idx]=max(lateness(candidates));
        job=candidates(idx);
        candidatesShops=setdiff(1:S,heaviest);
        [~,sortIdx]=sort(parent.shop_load(candidatesShops));
        candidatesShops=candidatesShops(sortIdx);
        shortened=remove_from_orders(orders,job);
        for target=candidatesShops
            trialOrder=shortened;
            trialOrder{target}(end+1)=job;
            candidate=evaluate_orders(parent,trialOrder,data,opts);
            if dominates(candidate.objectives,parent.objectives)
                improved=candidate; accepted=true; return;
            end
        end
    case 3 % Mf3: three procedures from uploaded LS_OU.m / manuscript.
        % A: swap last-delivered job with first job in its workshop.
        trans=parent.decode_transport;
        latest=trans(1,end); sh=shops(latest);
        seq=orders{sh};
        if numel(seq)>1
            other=seq(1);
            trial=orders; temp=trial{sh};
            a=find(temp==latest,1);b=find(temp==other,1);
            temp([a,b])=temp([b,a]);trial{sh}=temp;
            candidate=evaluate_orders(parent,trial,data,opts);
            if dominates(candidate.objectives,parent.objectives)
                improved=candidate;accepted=true;return;
            end
        end
        % B: reorder speed-switching jobs within a sampled workshop
        % by their first degradation-rate column (legacy LS_OU).
        sh=randi(S);seq=orders{sh};
        if numel(seq)>1
            switching=seq(parent.decode_m_utility(3,seq)>0);
            if numel(switching)>1
                [~,ii]=sort(data.degradationRates(switching,1));
                sorted=switching(ii);trial=orders;
                target=trial{sh};positions=find(ismember(target,switching));
                target(positions)=sorted;trial{sh}=target;
                candidate=evaluate_orders(parent,trial,data,opts);
                if dominates(candidate.objectives,parent.objectives)
                    improved=candidate;accepted=true;return;
                end
            end
        end
        % C: insert final job in its original workshop into each position.
        latest=trans(1,end);sh=shops(latest);seq=orders{sh};
        if numel(seq)>1
            seq(seq==latest)=[];
            for pos=1:numel(seq)+1
                trial=orders;trial{sh}=insert_at(seq,latest,pos);
                candidate=evaluate_orders(parent,trial,data,opts);
                if dominates(candidate.objectives,parent.objectives)
                    improved=candidate;accepted=true;return;
                end
            end
        end
    otherwise
        error('Unknown local search operator: %d.',method);
end
end

function orders = remove_from_orders(orders,job)
for shop=1:numel(orders)
    orders{shop}(orders{shop}==job)=[];
end
end

function sequence=insert_at(sequence,job,at)
sequence=[sequence(1:at-1),job,sequence(at:end)];
end

function candidate=evaluate_orders(parent,orders,data,opts)
% Canonical fractional keys preserve *exactly* the proposed job order.
chrom=parent.chrom;
for shop=1:data.shopCount
    jobs=orders{shop};
    if isempty(jobs), continue; end
    fractions=(1:numel(jobs))/(numel(jobs)+1);
    chrom(jobs)=shop+fractions;
end
candidate=parent;
candidate.chrom=chrom;
candidate.need_decode=true;
candidate=decode_pop(candidate,data,opts);
end

function flag=dominates(a,b)
flag=all(a<=b) && any(a<b);
end
