function refined = RLMA_energy_saving(individual, data, opts)
%RLMA_ENERGY_SAVING Manuscript Algorithm 4; keep vehicle/batch assignment.
% Condition 1: exchange final two jobs of a multi-job batch if energy
% does not increase and the two affected equipment utilities do not fall.
% Condition 2: when batch has exactly 3 jobs, swap first and last if
% transportation energy decreases and all three utilities do not fall.
% Full downstream delivery schedules are recomputed after a trial swap,
% preventing stale arrival times for later trips of the same vehicle.
refined=individual;
for b=1:numel(refined.batches)
    if numel(refined.batches(b).jobs)<2, continue; end
    pairs=[numel(refined.batches(b).jobs)-1,numel(refined.batches(b).jobs)];
    [refined,~]=try_swap(refined,b,pairs,data,opts,false);
    if numel(refined.batches(b).jobs)==3
        [refined,~]=try_swap(refined,b,[1,3],data,opts,true);
    end
end
end

function [current,accepted]=try_swap(current,b,pair,data,opts,strictEnergy)
accepted=false;
trial=current;
jobs=trial.batches(b).jobs;
jobs(pair)=jobs(fliplr(pair));
trial.batches(b).jobs=jobs;
[transport,batches,transportEnergy]=RLMA_evaluate_batches( ...
    trial.batches,data,current.production_completion,current.shop_assignment);
newUtility=OU_adjust(transport,data.failureTimes,data.speedEfficiency,data.degradationRates);
oldUtility=current.decode_m_utility(1,:);
energyOK=transportEnergy < current.trans_energy-1e-9;
if ~strictEnergy
    energyOK=transportEnergy<=current.trans_energy+1e-9;
end
% Check ALL equipment, not just changedJobs, because a later trip on the
% same vehicle can have different dispatch times after a route exchange.
utilityOK=all(newUtility(1,:) >= oldUtility-1e-10);
strictGain = transportEnergy<current.trans_energy-1e-9 || ...
             any(newUtility(1,:)>oldUtility+1e-10);
if energyOK && utilityOK && strictGain
    trial.decode_transport=transport;
    trial.decode_m_utility=newUtility;
    trial.batches=batches;
    trial.trans_energy=transportEnergy;
    energy=trial.pro_energy+transportEnergy;
    trial.objectives=[energy,max(trial.shop_load),1/sum(newUtility(1,:))];
    current=trial;
    accepted=true;
end
% The no-decrease check is stronger than checking changedJobs only.
end
