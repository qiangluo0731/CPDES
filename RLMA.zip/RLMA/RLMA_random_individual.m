function individual=RLMA_random_individual(data)
%RLMA_RANDOM_INDIVIDUAL Random HWP and UPV keys, 1-based shop integer part (Fig. 4).
n=data.jobCount;
indShop=randi(data.shopCount,1,n);
individual=struct();
individual.chrom=[indShop+rand(1,n),rand(1,data.vehicleCount)];
individual.need_decode=true;
individual.decode_shop=[];
individual.decode_transport=[];
individual.decode_m_utility=[];
individual.objectives=[];
individual.shop_load=[];
individual.shop_assignment=[];
individual.shop_orders=[];
individual.production_completion=[];
individual.batches=[];
individual.pro_energy=0;
individual.trans_energy=0;
end
