function results = RLMA(instanceDir, outputDir, opts)
%RLMA Batch-run the CPDES RLMA on AA_Ta*.mat benchmark instances.
%
% Recommended directory layout:
%   RLMA_folder/
%       RLMA.m  RLMA_*.m  decode_pop.m  OU_adjust.m
%       AA_Ta031_3_50_5.mat
%       AA_Ta031_5_50_5.mat
%       ...
%
% Usage (no arguments; instances and result files beside RLMA.m):
%   RLMA;
%
% Usage (custom options, same-directory input and output):
%   opts = RLMA_options();
%   opts.numRuns = 10;
%   RLMA([], [], opts);
%
% Usage (separate input and result directories):
%   results = RLMA('D:\CPDES\instances', 'D:\CPDES\results', opts);
%
% Inputs:
%   instanceDir : directory containing benchmark MAT-files. Empty uses
%                 the folder containing this RLMA.m file, NOT pwd.
%   outputDir   : folder to save result_all_*.mat. Empty uses instanceDir.
%   opts        : options returned by RLMA_options(), with optional overrides.
%
% Results:
%   AA_Ta031_3_50_5.mat -> result_all_031_3_50_5.mat
%   Each result MAT-file includes the three legacy variable names:
%       Population_first, PF_mean_value, Population_child_all
%   and also runDetails, resultMetadata.
%
%   The returned cell array contains one status/summary per input instance.
%   Full populations stay on disk unless opts.keepResultsInMemory=true.
%
% Safety:
%   Existing results are skipped by default. Set opts.overwriteExisting=true
%   to recompute and replace them. Errors are recorded and other instances
%   continue, unless opts.continueOnError=false.

algorithmDir = fileparts(mfilename('fullpath'));
if nargin < 1 || isempty(instanceDir)
    instanceDir = algorithmDir;
end
if nargin < 2 || isempty(outputDir)
    outputDir = instanceDir;
end
if nargin < 3 || isempty(opts)
    opts = RLMA_options();
else
    % Backward-compatible options: fill fields introduced in later versions.
    defaults = RLMA_options();
    fields = fieldnames(defaults);
    for f = 1:numel(fields)
        if ~isfield(opts, fields{f})
            opts.(fields{f}) = defaults.(fields{f});
        end
    end
end

assert(ischar(instanceDir) && exist(instanceDir, 'dir') == 7, ...
    'RLMA:InstanceDirectory', 'Instance directory does not exist: %s', instanceDir);
assert(ischar(outputDir), 'RLMA:OutputDirectory', 'Output directory must be a character path.');
if exist(outputDir, 'dir') ~= 7
    [created, message] = mkdir(outputDir);
    assert(created, 'RLMA:CreateDirectory', 'Cannot create output directory: %s', message);
end

% Restrict the input file pattern: old result_all_*.mat files in the same
% directory must never be mistaken for new benchmark inputs.
files = dir(fullfile(instanceDir, opts.instancePattern));
files = files(~[files.isdir]);
assert(~isempty(files), 'RLMA:NoInstances', ...
    ['No input files matching "%s" in %s. Check that Windows did not hide ', ...
     'the actual extension and that each benchmark is a MATLAB .mat file.'], ...
    opts.instancePattern, instanceDir);

% Explicit alphabetical order for deterministic, reproducible batch runs.
names = {files.name};
orderNames = cellfun(@lower, names, 'UniformOutput', false);
[~, order] = sort(orderNames);
files = files(order);
numInstances = numel(files);

% Plan all output names up front and check for collisions (never overwrite
% distinct input instances that map to the same result_all_*.mat filename).
outputPaths = cell(1, numInstances);
for i = 1:numInstances
    [~, stem] = fileparts(files(i).name);
    prefix = opts.resultStripPrefix;
    if ~isempty(prefix) && strncmpi(stem, prefix, numel(prefix))
        resultStem = stem(numel(prefix)+1:end);
    else
        resultStem = stem;
    end
    assert(~isempty(resultStem), 'RLMA:InvalidFilename', ...
        'Could not derive result filename from %s.', files(i).name);
    outputPaths{i} = fullfile(outputDir, ['result_all_', resultStem, '.mat']);
end
normalizedNames = cellfun(@lower, outputPaths, 'UniformOutput', false);
assert(numel(unique(normalizedNames)) == numInstances, 'RLMA:OutputCollision', ...
    'Different input instance names map to the same result filename.');

results = cell(1, numInstances);
if opts.printProgress
    fprintf('RLMA: %d instance(s), input: %s\n', numInstances, instanceDir);
    fprintf('RLMA: result directory: %s\n', outputDir);
    fprintf('RLMA: runs per instance = %d\n', opts.numRuns);
end

for i = 1:numInstances
    infile = fullfile(instanceDir, files(i).name);
    outfile = outputPaths{i};
    info = struct('inputFile', infile, 'resultFile', outfile, ...
        'status', '', 'PFSize', NaN, 'PF_mean_value', [], ...
        'elapsedSeconds', NaN, 'runCount', opts.numRuns, 'message', '', ...
        'fullResult', []);

    if exist(outfile, 'file') == 2 && ~opts.overwriteExisting
        info.status = 'skipped';
        info.message = 'Output exists; set opts.overwriteExisting=true to recompute.';
        if opts.printProgress
            fprintf('[%d/%d] SKIP: %s (already exists)\n', ...
                i, numInstances, files(i).name);
        end
    else
        if opts.printProgress
            fprintf('[%d/%d] START: %s\n', i, numInstances, files(i).name);
        end
        watch = tic;
        try
            data = RLMA_load_instance(infile);
            solved = RLMA_solve(data, opts);

            % Retain compatibility with the legacy result_all_*.mat format.
            Population_first = solved.Population_first; %#ok<NASGU>
            PF_mean_value = solved.PF_mean_value; %#ok<NASGU>
            Population_child_all = solved.Population_child_all; %#ok<NASGU>
            runDetails = solved.perRun; %#ok<NASGU>
            resultMetadata = rmfield(solved, ...
                {'Population_first', 'PF_mean_value', 'Population_child_all', 'perRun'}); %#ok<NASGU>
            resultMetadata.sourceFile = files(i).name;
            resultMetadata.outputFile = outfile;
            resultMetadata.savedAt = datestr(now, 31);

            % Save atomically through a temporary file. If the solver
            % crashes or disk is full, any old result remains intact.
            temporaryFile = [tempname(outputDir), '.mat'];
            try
                save(temporaryFile, 'Population_first', 'PF_mean_value', ...
                    'Population_child_all', 'runDetails', 'resultMetadata', '-v7');
                [moved, moveMessage] = movefile(temporaryFile, outfile, 'f');
                assert(moved, 'RLMA:MoveResult', '%s', moveMessage);
            catch saveError
                if exist(temporaryFile, 'file') == 2
                    delete(temporaryFile);
                end
                rethrow(saveError);
            end
            info.status = 'completed';
            info.PFSize = numel(Population_first);
            info.PF_mean_value = PF_mean_value;
            info.elapsedSeconds = toc(watch);
            if opts.keepResultsInMemory
                info.fullResult = solved;
            end
            if opts.printProgress
                fprintf('[%d/%d] SAVED: %s | PF=%d | %.2fs\n', ...
                    i, numInstances, outfile, info.PFSize, info.elapsedSeconds);
            end
        catch solveError
            info.status = 'failed';
            info.message = solveError.message;
            info.elapsedSeconds = toc(watch);
            warning('RLMA:InstanceFailed', ...
                'Instance %s failed: %s', files(i).name, solveError.message);
            if ~opts.continueOnError
                results{i} = info;
                save(fullfile(outputDir, 'RLMA_batch_summary.mat'), 'results', '-v7');
                rethrow(solveError);
            end
        end
    end
    results{i} = info;

    % Checkpoint after EACH instance so an interrupted batch can be resumed.
    save(fullfile(outputDir, 'RLMA_batch_summary.mat'), 'results', '-v7');
end

if opts.printProgress
    states = cellfun(@(x) x.status, results, 'UniformOutput', false);
    fprintf('RLMA batch done: completed=%d, skipped=%d, failed=%d.\n', ...
        sum(strcmp(states,'completed')), sum(strcmp(states,'skipped')), ...
        sum(strcmp(states,'failed')));
end
end
