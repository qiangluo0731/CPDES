function result=RLMA_solve(data, opts)
%RLMA_SOLVE Self-contained Q-learning-driven memetic search for one instance.
% Order of objectives: [total energy, maximum workshop load, inverse OU].
% Four evolutionary actions: GA, DE, Jaya, GWO (indices 1,2,3,4).
% No global variables, legacy local-search files, or Statistics Toolbox.
if nargin<2 || isempty(opts), opts=RLMA_options(); end
n=data.jobCount;
if isempty(opts.timeLimit)
    limit=n*data.shopCount*data.vehicleCount*opts.timeFactor;
else
    limit=opts.timeLimit;
end
assert(isscalar(limit) && limit>0, 'Positive time limit required.');
assert(opts.populationSize>=4 && opts.numRuns>=1, 'Invalid population size / run count.');
assert(opts.learningRate>0 && opts.learningRate<=1 && opts.discount>=0 && opts.discount<=1, 'Invalid Q-learning parameters.');
PS=opts.populationSize;
allPF=struct([]);
runDetails=cell(1,opts.numRuns);
for run=1:opts.numRuns
    rng(opts.randomSeed+run-1,'twister');
    timer=tic;
    pop=repmat(RLMA_random_individual(data),1,PS);
    for i=1:PS, pop(i)=RLMA_random_individual(data); end
    [pop,frontNo,~]=RLMA_environmental(pop,PS,data,opts);
    obj=reshape([pop.objectives],3,[])';
    objectiveScale=max(obj,[],1)-min(obj,[],1);
    objectiveScale=max(objectiveScale,1e-8);
    Q=zeros(4,4);
    state=4; % Initial state: neither metric has yet shown improvement.
    generation=0;
    history=zeros(0,7); % time, action, reward, GD, Spread, PF-count, epsilon
    [oldGD,oldSpread]=RLMA_metrics(pop,objectiveScale,opts.initialReference);
    while toc(timer)<limit && generation<opts.maxGenerations
        generation=generation+1;
        fraction=min(1,toc(timer)/limit);
        epsilon=opts.explorationStart+(opts.explorationEnd-opts.explorationStart)*fraction;
        epsilon=max(0,min(1,epsilon));
        % Corrected epsilon-greedy: exploration decreases over elapsed time.
        if rand<epsilon || all(Q(state,:)==0)
            action=randi(4);
        else
            [~,action]=max(Q(state,:));
        end
        offspring=RLMA_operator(pop,action,data,opts);
        offspring=decode_pop(offspring,data,opts);
        [pop,frontNo,~]=RLMA_environmental([pop,offspring],PS,data,opts);
        [newGD,newSpread]=RLMA_metrics(pop,objectiveScale,opts.initialReference);
        deltaGD=newGD-oldGD;                  % < 0 means convergence improves
        deltaSpread=newSpread-oldSpread;       % < 0 means distribution improves

        % Revised manuscript Eq. (45): both minimization-type indicators.
        if deltaGD < -1e-12 && deltaSpread < -1e-12
            reward=10;
        elseif deltaGD < -1e-12 || deltaSpread < -1e-12
            reward=5;
        else
            reward=0;
        end
        nextState=RLMA_state(deltaGD,deltaSpread);
        Q(state,action)=Q(state,action) + opts.learningRate* ...
            (reward+opts.discount*max(Q(nextState,:))-Q(state,action));
        state=nextState;
        oldGD=newGD;
        oldSpread=newSpread;

        if toc(timer)>opts.localSearchStart*limit
            front=find(frontNo==1);
            if isfinite(opts.localSearchMaxIndividuals)
                front=front(1:min(numel(front),opts.localSearchMaxIndividuals));
            end
            localCandidates=struct([]);
            for j=1:numel(front)
                if toc(timer)>=limit, break; end
                method=randi(3);
                [refined,accepted]=RLMA_local_search(pop(front(j)),method,data,opts);
                if accepted
                    if isempty(localCandidates),localCandidates=refined;
                    else,localCandidates(end+1)=refined; end %#ok<AGROW>
                end
            end
            if ~isempty(localCandidates)
                [pop,frontNo,~]=RLMA_environmental([pop,localCandidates],PS,data,opts);
            end
        end
        if ~isempty(pop)
            % GD state for next iteration reflects the current population,
            % including any solutions contributed by local search.
            [oldGD,oldSpread]=RLMA_metrics(pop,objectiveScale,opts.initialReference);
        end
        history(end+1,:)=[toc(timer),action,reward,oldGD,oldSpread,sum(frontNo==1),epsilon]; %#ok<AGROW>
    end
    runPF=pop(frontNo==1);
    if isempty(allPF)
        allPF=runPF;
    else
        allPF=[allPF,runPF]; %#ok<AGROW>
    end
    runDetails{run}=struct('seed',opts.randomSeed+run-1, ...
        'elapsed',toc(timer),'generations',generation,'Qtable',Q, ...
        'PFSize',numel(runPF),'history',history);
    if opts.printProgress
        fprintf('[%s] run %d/%d: PF=%d, generations=%d, %.2fs\n', ...
            data.name,run,opts.numRuns,numel(runPF),generation,toc(timer));
    end
end
% Aggregate and remove duplicate objective vectors across independent runs.
allObjectives=reshape([allPF.objectives],3,[])';
[~,idx]=unique(allObjectives,'rows','stable');
allPF=allPF(sort(idx));
[rank,~]=RLMA_rank(reshape([allPF.objectives],3,[])');
PF=allPF(rank==1);
% Algorithm 4 is a postprocessing step, rather than genetic encoding change.
for i=1:numel(PF)
    PF(i)=RLMA_energy_saving(PF(i),data,opts);
end
% Refilter dominance after postprocessing so output really remains a PF.
newObj=reshape([PF.objectives],3,[])';
[~,idx]=unique(newObj,'rows','stable');
PF=PF(sort(idx));
[rank,~]=RLMA_rank(reshape([PF.objectives],3,[])');
PF=PF(rank==1);
obj=reshape([PF.objectives],3,[])';
result=struct('Population_first',PF, 'PF_mean_value',mean(obj,1), ...
    'Population_child_all',allPF, 'perRun',{runDetails}, ...
    'objectiveOrder',{{'totalEnergy','maxWorkshopLoad','inverseTotalUtility'}}, ...
    'instanceName',data.name,'options',opts);
end
