function chromosome = RLMA_repair_chrom(chromosome, data)
%RLMA_REPAIR_CHROM Keep workshop assignment integer part and random-key range.
% Maps candidate real-valued coordinates to [1,S+1) and [0,1) without
% producing the forbidden upper endpoint; mutation/variation remains legal.
n=data.jobCount;
S=data.shopCount;
chromosome=real(chromosome(:)');
assert(numel(chromosome)==n+data.vehicleCount && all(isfinite(chromosome)), 'Cannot repair invalid chromosome.');
chromosome(1:n)=1+mod(chromosome(1:n)-1,S);
chromosome(n+1:end)=mod(chromosome(n+1:end),1);
% Preserve small but positive fractional keys if an exact integer appears.
% Zero fractional keys are mathematically valid; job-id breaks ties.
end
