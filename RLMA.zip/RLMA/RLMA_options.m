function opts = RLMA_options()
%RLMA_OPTIONS Default settings for the manuscript-aligned RLMA solver.
% All objectives are minimized in the order [energy, workload, 1/sum(OU)].
% MATLAB R2016a-compatible. Adjust opts before calling RLMA/RLMA_solve.
opts.populationSize = 80;
opts.numRuns = 30;                     % Section 5 of the manuscript
opts.timeFactor = 0.1;                % N * S * V * 0.1 seconds
opts.timeLimit = [];                  % [] -> use timeFactor
opts.GWO_U = 0.01;
opts.DE_F = 0.5;
opts.discount = 0.6;
opts.learningRate = 0.2;
opts.explorationStart = 1.0;
opts.explorationEnd = 0.0;
opts.localSearchStart = 0.5;         % fraction of elapsed time
opts.localSearchMaxIndividuals = Inf;
opts.randomSeed = 20261017;
opts.printProgress = true;
opts.savePerRun = true;
opts.maxGenerations = Inf;           % optional deterministic test control
opts.initialReference = [0, 0, 0];   % predefined reference point P* used by GD

% Batch execution: place AA_Ta*.mat beside RLMA.m, then type RLMA.
opts.instancePattern = 'AA_Ta*.mat';  % case-insensitive matching on Windows
opts.resultStripPrefix = 'AA_Ta';    % AA_Ta031_3_50_5 -> result_all_031_3_50_5.mat
opts.overwriteExisting = false;       % protect previously saved experiments
opts.continueOnError = true;          % record failure and proceed to next case
opts.keepResultsInMemory = false;     % avoid storing all full Pareto populations

end
