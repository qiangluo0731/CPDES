function offspring=RLMA_operator(pop,action,data,opts)
%RLMA_OPERATOR Manuscript operator mapping: 1 GA, 2 DE, 3 Jaya, 4 GWO.
% Reconstructed from uploaded crossPopulate, mutatePopulate, DE, Jaya,
% DivideWolf and NPUM with corrected indexing and no global variables.
N=numel(pop); n=data.jobCount; v=data.vehicleCount; S=data.shopCount;
X=reshape([pop.chrom],n+v,[])';
obj=reshape([pop.objectives],3,[])';
[front,crowd]=RLMA_rank(obj);
Y=zeros(N,n+v);
switch action
 case 1 % Binary-mask crossover on HWP, followed by mutation of HWP and UPV.
   for k=1:N
      parents=randperm(N,min(2,N));
      if numel(parents)<2,parents=[1,1];end
      c=X(parents(1),:); d=X(parents(2),:);
      mask=rand(1,n)<0.5; c(mask)=d(mask);
      if S>1
          j=randi(n); current=floor(c(j)); choices=setdiff(1:S,current);
          c(j)=choices(randi(numel(choices)))+rand;
      end
      if v>0,c(n+randi(v))=rand;end
      if n>1,ij=randperm(n,2);c(ij)=c(fliplr(ij));ij=randperm(n,2);c(ij)=c(fliplr(ij));end
      if v>1,ij=n+randperm(v,2);c(ij)=c(fliplr(ij));end
      % Retain legacy job-position insertion of encoded keys.
      if n>1, ij=randperm(n,2);h=c(1:n); val=h(ij(1));h(ij(1))=[];h=[h(1:ij(2)-1),val,h(ij(2):end)];c(1:n)=h;end
      Y(k,:)=c;
   end
 case 2 % Uploaded DE: one common difference pair, random HWP mask.
   pair=randperm(N,2); a=X(pair(1),:); b=X(pair(2),:);
   for k=1:N
       c=X(k,:);mask=rand(1,n)<0.5;c(1:n)=c(1:n)+opts.DE_F*(a(1:n)-b(1:n)).*mask;
       c=RLMA_repair_chrom(c,data);
       % Legacy DE then calls crossover and selects one of four children.
       other=X(k,:); z=c; mask=rand(1,n)<0.5;
       r1=other;r2=z;r1(mask)=z(mask);r2(mask)=other(mask);
       pool=[other;z;r1;r2];c=pool(randi(4),:);Y(k,:)=c;
   end
 case 3 % Uploaded Jaya: best/worst selected by non-dominated rank.
   best=find(front==1);worst=find(front==max(front));
   for k=1:N
      a=X(best(randi(numel(best))),:);b=X(worst(randi(numel(worst))),:);
      c=X(k,:);mask=rand(1,n)<0.5;
      c(1:n)=c(1:n)+mask.*(rand*(a(1:n)-c(1:n))-rand*(b(1:n)-c(1:n)));
      Y(k,:)=c;
   end
 case 4 % Uploaded NPUM: average three positive and three negative wolves.
   ranked=find(front==1);secondary=find(front==2);
   if numel(ranked)>=3
       good=ranked(randi(numel(ranked),1,3));
   else
       [~,ix]=sortrows([front(:),-crowd(:),(1:N)'],[1,2,3]);
       good=ix(1:min(3,N));good(end+1:3)=good(end);
   end
   [~,w1]=max(obj(:,1));[~,w2]=max(obj(:,2));
   weakest=find(front==max(front));[~,loc]=min(crowd(weakest));w3=weakest(loc);
   positive=mean(X(good,:),1);negative=mean(X([w1,w2,w3],:),1);
   for k=1:N
       c=X(k,:); mask=rand(1,n)<0.5;r=rand(1,2);
       c(1:n)=c(1:n)+mask.*opts.GWO_U.*(r(1)*(positive(1:n)-c(1:n))+r(2)*(c(1:n)-negative(1:n)));
       Y(k,:)=c;
   end
 otherwise,error('Unknown action %d.',action);
end
% Keep the decoded workshop integer valid, and preserve unchanged UPV
% in DE / Jaya / GWO just as in the uploaded original operators.
offspring=repmat(pop(1),1,N);
for k=1:N
    offspring(k).chrom=RLMA_repair_chrom(Y(k,:),data);
    offspring(k).need_decode=true;
end
end
