function pop = decode_pop(pop, data, opts)
%DECODE_POP Decode HWP/UPV chromosomes into all CPDES decisions.
% INPUT:
%   pop(k).chrom: 1-by-(N+V), with HWP in [1,S+1) and UPV in [0,1).
%   data: struct returned by RLMA_load_instance, or compatible struct.
%   opts: struct returned by RLMA_options.
% OUTPUT: population with production schedule, transport batches,
%   equipment utility, and objectives ordered [energy, max load, 1/sum(OU)].
% Energy objective follows manuscript Eq. (2) exactly:
% E_total = E_processing + E_idle + E_transport (no scaling/rounding).
if nargin<3 || isempty(opts)
    opts = RLMA_options();
end
n = data.jobCount;
S = data.shopCount;
M = data.stageCount;
V = data.vehicleCount;
for ind=1:numel(pop)
    if isfield(pop,'need_decode') && ~pop(ind).need_decode
        continue;
    end
    chrom = double(pop(ind).chrom(:)');
    assert(numel(chrom)==n+V && all(isfinite(chrom)), 'Invalid chromosome size/values.');
    assert(all(chrom(1:n)>=1) && all(chrom(1:n)<S+1), 'HWP out of [1,S+1).');
    assert(all(chrom(n+1:end)>=0) && all(chrom(n+1:end)<1), 'UPV out of [0,1).');
    shopIDs = floor(chrom(1:n));
    priorities = chrom(1:n)-floor(chrom(1:n));
    shopOrder = cell(1,S);
    shopSchedules = cell(1,S);
    completion = zeros(1,n);
    shopLoad = zeros(1,S);
    productionEnergy = 0;

    for shop=1:S
        jobs = find(shopIDs==shop);
        if isempty(jobs)
            shopSchedules{shop}=zeros(0,1+2*M);
            shopOrder{shop}=zeros(1,0);
            continue;
        end
        keys = priorities(jobs);
        [~,order] = sortrows([keys(:),jobs(:)], [1 2]);
        jobs = jobs(order);
        shopOrder{shop} = jobs;
        schedule = zeros(numel(jobs),1+2*M);
        schedule(:,1) = jobs(:);
        lastEnd = zeros(1,M);
        for jIdx=1:numel(jobs)
            job = jobs(jIdx);
            priorStageEnd = 0;
            for stage=1:M
                startTime = max(lastEnd(stage),priorStageEnd);
                duration = data.timeSet{shop}(job,stage);
                finishTime = startTime+duration;
                schedule(jIdx,2*stage:2*stage+1) = [startTime,finishTime];
                productionEnergy = productionEnergy ...
                    + duration*data.energySet{shop}(1,stage) ...
                    + (startTime-lastEnd(stage))*data.energySet{shop}(2,stage);
                lastEnd(stage) = finishTime;
                priorStageEnd = finishTime;
            end
            completion(job) = lastEnd(M);
        end
        shopLoad(shop) = sum(sum(data.timeSet{shop}(jobs,:)));
        shopSchedules{shop}=schedule;
    end

    % Complete-job order is determined by production completion time.
    [~,completionOrder] = sortrows([completion(:),(1:n)'],[1,2]);
    completionOrder = completionOrder(:)';
    [~,vehiclePriority] = sortrows([chrom(n+1:n+V)',(1:V)'],[1,2]);
    vehiclePriority = vehiclePriority(:)';
    vehicleAvailable = zeros(1,V);
    batches = struct('vehicle',{},'jobs',{},'departure',{},'returnTime',{},'energy',{});
    remaining = completionOrder;
    while ~isempty(remaining)
        % Only select vehicles able to accommodate the first waiting job.
        eligible = find(data.vehicleCapacity>=data.jobWeights(remaining(1))-1e-10);
        assert(~isempty(eligible), 'No vehicle can carry job %d.',remaining(1));
        earliest = min(vehicleAvailable(eligible));
        tied = eligible(abs(vehicleAvailable(eligible)-earliest)<=1e-9);
        priorityPos = find(ismember(vehiclePriority,tied),1,'first');
        car = vehiclePriority(priorityPos);
        cumulativeWeight = cumsum(data.jobWeights(remaining));
        count = sum(cumulativeWeight<=data.vehicleCapacity(car)+1e-10);
        assert(count>=1, 'Internal batch construction error.');
        jobs = remaining(1:count);
        remaining(1:count)=[];

        % Reserve this vehicle until it finishes the current trip.
        depart = max(vehicleAvailable(car),max(completion(jobs)));
        prev = 0;
        arrival = depart;
        for j=jobs
            if prev==0
                dist = data.depotDistance(j);
            else
                dist = data.customerDistance(prev,j);
            end
            arrival = arrival+dist/data.vehicleSpeed(1,car);
            prev = j;
        end
        vehicleAvailable(car) = arrival+data.depotDistance(prev)/data.vehicleSpeed(2,car);
        b=length(batches)+1;
        batches(b).vehicle = car;
        batches(b).jobs = jobs;
        batches(b).departure = depart;
        batches(b).returnTime = vehicleAvailable(car);
        batches(b).energy = 0;
    end
    [transport,batches,transportEnergy] = RLMA_evaluate_batches(batches,data,completion,shopIDs);
    utility = OU_adjust(transport,data.failureTimes,data.speedEfficiency,data.degradationRates);
    totalUtility = sum(utility(1,:));
    assert(isfinite(totalUtility) && totalUtility>0, 'Invalid total utility.');

    energy = productionEnergy + transportEnergy;
    pop(ind).decode_shop = shopSchedules;
    pop(ind).decode_transport = transport;
    pop(ind).decode_m_utility = utility;
    pop(ind).objectives = [energy,max(shopLoad),1/totalUtility];
    pop(ind).shop_load = shopLoad;
    pop(ind).shop_assignment = shopIDs;
    pop(ind).shop_orders = shopOrder;
    pop(ind).production_completion = completion;
    pop(ind).batches = batches;
    pop(ind).pro_energy = productionEnergy;
    pop(ind).trans_energy = transportEnergy;
    pop(ind).need_decode = false;
end
end
