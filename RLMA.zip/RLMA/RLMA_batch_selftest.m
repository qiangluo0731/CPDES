function RLMA_batch_selftest()
%RLMA_BATCH_SELFTEST Check same-folder scan, prefix removal, output and resume.
% Requires only base MATLAB. Does not require the real benchmark dataset.
% Does not modify any real benchmark or legacy result file.

root = tempname;
mkdir(root);
cleanup = onCleanup(@() localDeleteTemporaryFolder(root)); %#ok<NASGU>

% Construct a tiny benchmark with the original data-cell layout.
N = 4; M = 2; S = 2;
job_set = cell(1,6); %#ok<NASGU>
job_set{1} = [N,M];
job_set{2} = [1 2 3 4; 2 1 3 2];
job_set{3} = [1 1 1 1];
job_set{4} = repmat([2 1],N,1);
job_set{5} = repmat([0.10 0.04],N,1);
job_set{6} = repmat([10 25],N,1);
manufacturer_set = cell(1,4); %#ok<NASGU>
manufacturer_set{1} = [0;0];
manufacturer_set{2} = S;
manufacturer_set{3} = {ones(N,M)*2, ones(N,M)*3};
manufacturer_set{4} = {[3 4; 0.5 0.4], [4 3; 0.5 0.4]};
servicer_set = cell(1,4); %#ok<NASGU>
servicer_set{1} = [0 0; 0 0];
servicer_set{2} = [1 1; 2 2];
servicer_set{3} = [2 2; 0.5 0.5];
servicer_set{4} = [2 2];

save(fullfile(root, 'AA_Ta031_3_50_5.mat'), ...
    'job_set', 'manufacturer_set', 'servicer_set');
save(fullfile(root, 'AA_Ta031_5_50_5.mat'), ...
    'job_set', 'manufacturer_set', 'servicer_set');
% Must not try to decode an existing result as an input instance.
unrelated_data = 123; %#ok<NASGU>
save(fullfile(root, 'result_all_999_3_50_5.mat'), 'unrelated_data');

opts = RLMA_options();
opts.numRuns = 1;
opts.populationSize = 8;
opts.timeLimit = 0.2;
opts.maxGenerations = 2;
opts.localSearchMaxIndividuals = 1;
opts.printProgress = false;
opts.overwriteExisting = false;
opts.continueOnError = false;

out = RLMA(root, root, opts);
assert(numel(out) == 2, 'Failed to filter benchmark input files.');
assert(all(cellfun(@(x) strcmp(x.status,'completed'),out)), ...
    'First batch did not complete.');
for k = 1:2
    assert(exist(out{k}.resultFile, 'file') == 2, 'Result file missing.');
    variables = whos('-file', out{k}.resultFile);
    names = {variables.name};
    assert(all(ismember({'Population_first','PF_mean_value', ...
        'Population_child_all','runDetails','resultMetadata'}, names)), ...
        'Missing required legacy result variables.');
end
assert(exist(fullfile(root,'result_all_031_3_50_5.mat'),'file')==2);
assert(exist(fullfile(root,'result_all_031_5_50_5.mat'),'file')==2);
assert(exist(fullfile(root,'RLMA_batch_summary.mat'),'file')==2);

% A resumed batch must skip existing result files without replacing them.
again = RLMA(root, root, opts);
assert(all(cellfun(@(x) strcmp(x.status,'skipped'),again)), ...
    'Existing outputs were not skipped safely.');
fprintf('RLMA_batch_selftest PASSED: discovery, ordering, naming, saving, resume.\n');
end

function localDeleteTemporaryFolder(folder)
if exist(folder,'dir')==7
    rmdir(folder,'s');
end
end
