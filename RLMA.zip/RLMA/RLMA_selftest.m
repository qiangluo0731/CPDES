function RLMA_selftest()
%RLMA_SELFTEST Lightweight deterministic structural smoke test.
% Run in MATLAB: addpath('path_to_package'); RLMA_selftest;
% This test does not replace the manuscript's 120-instance experiments.
rng(15,'twister');
N=6; S=2; M=3; V=2;
data=struct();
data.name='synthetic_smoke';
data.jobCount=N;
data.stageCount=M;
data.shopCount=S;
data.vehicleCount=V;
data.jobWeights=[1,1.5,0.8,1.2,1,1.2];
data.timeSet={randi([1,3],N,M),randi([2,4],N,M)};
data.energySet={[2 3 2; 0.2 0.2 0.2],[2.5 2 3; 0.1 0.15 0.15]};
data.depotDistance=[2,3,4,4,2.5,3.5];
P=[2 0;3 1;0 4;4 0;1 2;2 3];
data.customerDistance=zeros(N,N);
for i=1:N
    diff=bsxfun(@minus,P,P(i,:));
    data.customerDistance(i,:)=sqrt(sum(diff.^2,2))';
end
data.vehicleSpeed=[1 1.3;1.5 1.5];
data.vehicleEnergyRate=[2 2.5;0.5 0.6];
data.vehicleCapacity=[3.5,4];
data.speedEfficiency=repmat([2 1],N,1);
data.failureTimes=repmat([10 25],N,1);
data.degradationRates=repmat([0.10 0.04],N,1);

opts=RLMA_options();
opts.populationSize=8;
opts.numRuns=1;
opts.timeLimit=1;
opts.maxGenerations=3;
opts.localSearchMaxIndividuals=2;
opts.printProgress=false;
pop=repmat(RLMA_random_individual(data),1,6);
for i=1:numel(pop),pop(i)=RLMA_random_individual(data);end
pop=decode_pop(pop,data,opts);
for i=1:numel(pop)
    p=pop(i);
    assert(all(isfinite(p.objectives)) && all(p.objectives>0));
    assert(isequal(sort(p.decode_transport(1,:)),1:N));
    assert(max(abs(p.objectives(1)-(p.pro_energy+p.trans_energy)))<1e-8);
    assert(abs(p.objectives(3)-1/sum(p.decode_m_utility(1,:)))<1e-10);
    assert(all(p.decode_transport(6,:)>=p.decode_transport(5,:)));
    for b=1:numel(p.batches)
        bs=p.batches(b);
        assert(sum(data.jobWeights(bs.jobs))<=data.vehicleCapacity(bs.vehicle)+1e-8);
    end
end
% A tie between idle vehicles is resolved by UPV priority.
tieCase=RLMA_random_individual(data);
tieCase.chrom(1:N)=1+(1:N)/(N+1);
tieCase.chrom(N+1:end)=[0.8,0.1]; % vehicle 2 ranks ahead of vehicle 1
tieCase=decode_pop(tieCase,data,opts);
assert(tieCase.batches(1).vehicle==2, 'UPV tie-breaking failed.');
for method=1:3
    [candidate,improved]=RLMA_local_search(pop(1),method,data,opts);
    if improved
        assert(all(candidate.objectives<=pop(1).objectives));
    end
end
refined=RLMA_energy_saving(pop(1),data,opts);
assert(refined.trans_energy<=pop(1).trans_energy+1e-8);
assert(all(refined.decode_m_utility(1,:)>=pop(1).decode_m_utility(1,:)-1e-9));
assert(RLMA_state(-1,1)==3 && RLMA_state(1,-1)==2);

% Analytic two-speed cases: earliest, intermediate, slowest-time.
testSchedule=zeros(7,3);
testSchedule(1,:)=[1 2 3];
testSchedule(6,:)=[10 17.5 30];
t=[10 25;10 25;10 25];
u=OU_adjust(testSchedule,t,repmat([2 1],3,1),repmat([.1 .04],3,1));
assert(abs(u(1,1)-1)<1e-12);
assert(abs(u(1,2)-( (10*(25-17.5)/(25-10))*2+ ...
    (17.5-10*(25-17.5)/(25-10))*1 )/20)<1e-12);
assert(abs(u(1,3)-25/20)<1e-12);

res=RLMA_solve(data,opts);
assert(~isempty(res.Population_first),'Final Pareto set is empty.');
assert(all(isfinite(res.PF_mean_value)),'Nonfinite Pareto objective.');
fprintf('RLMA_selftest PASSED: PF=%d; mean=[%.5g, %.5g, %.5g]\n', ...
    numel(res.Population_first),res.PF_mean_value);
end
