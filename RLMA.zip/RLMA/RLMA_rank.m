function [rank, crowding] = RLMA_rank(objectives)
%RLMA_RANK Nondominated ranking and NSGA-II crowding distance (minimization).
n=size(objectives,1);
rank=inf(n,1);
crowding=zeros(n,1);
if n==0, return; end
beats=cell(n,1);
dominatedBy=zeros(n,1);
for i=1:n-1
    for j=i+1:n
        idom=all(objectives(i,:)<=objectives(j,:)) && any(objectives(i,:)<objectives(j,:));
        jdom=all(objectives(j,:)<=objectives(i,:)) && any(objectives(j,:)<objectives(i,:));
        if idom
            beats{i}(end+1)=j;
            dominatedBy(j)=dominatedBy(j)+1;
        elseif jdom
            beats{j}(end+1)=i;
            dominatedBy(i)=dominatedBy(i)+1;
        end
    end
end
current=find(dominatedBy==0)';
f=1;
while ~isempty(current)
    rank(current)=f;
    next=[];
    for i=current
        for j=beats{i}
            dominatedBy(j)=dominatedBy(j)-1;
            if dominatedBy(j)==0, next(end+1)=j; end %#ok<AGROW>
        end
    end
    current=next;
    f=f+1;
end
for f=1:max(rank)
    indices=find(rank==f);
    K=numel(indices);
    if K<=2
        crowding(indices)=Inf;
        continue;
    end
    for m=1:size(objectives,2)
        [vals,sortIdx]=sort(objectives(indices,m));
        crowding(indices(sortIdx([1,end])))=Inf;
        r=vals(end)-vals(1);
        if r<=eps, continue; end
        for k=2:K-1
            idx=indices(sortIdx(k));
            if isfinite(crowding(idx))
                crowding(idx)=crowding(idx)+(vals(k+1)-vals(k-1))/r;
            end
        end
    end
end
end
