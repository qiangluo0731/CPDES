function [transport, batches, transportEnergy] = RLMA_evaluate_batches(batches, data, completionTime, shopOfJob)
%RLMA_EVALUATE_BATCHES Evaluate fixed vehicle/batch/route assignments.
% A vehicle cannot leave before its previous return or all batch jobs finish.
% Loaded legs use vehicleSpeed(1,v), empty return vehicleSpeed(2,v).
% Row definition of the 7-by-N schedule:
% 1 job ID; 2 production completion; 3 job weight; 4 vehicle ID;
% 5 start of that job's transport leg; 6 customer delivery; 7 shop ID.
n = data.jobCount;
V = data.vehicleCount;
transport = zeros(7,n);
vehicleAvailable = zeros(1,V);
transportEnergy = 0;
column = 0;
seen = false(1,n);
for b=1:numel(batches)
    car = batches(b).vehicle;
    jobs = batches(b).jobs(:)';
    assert(car>=1 && car<=V && numel(jobs)>=1, 'Invalid batch or vehicle.');
    assert(all(jobs>=1) && all(jobs<=n) && ~any(seen(jobs)), 'Invalid/duplicate job in route.');
    assert(sum(data.jobWeights(jobs))<=data.vehicleCapacity(car)+1e-9, 'Batch over vehicle capacity.');
    depart = max(vehicleAvailable(car),max(completionTime(jobs)));
    now = depart;
    prev = 0;
    energy = 0;
    for k=1:numel(jobs)
        j=jobs(k);
        if prev==0
            distance = data.depotDistance(j);
        else
            distance = data.customerDistance(prev,j);
        end
        legStart = now;
        travelTime = distance/data.vehicleSpeed(1,car);
        now = now+travelTime;
        energy = energy+travelTime*data.vehicleEnergyRate(1,car);
        column = column+1;
        transport(:,column) = [j;completionTime(j);data.jobWeights(j);car;legStart;now;shopOfJob(j)];
        seen(j) = true;
        prev = j;
    end
    emptyTime = data.depotDistance(prev)/data.vehicleSpeed(2,car);
    energy = energy+emptyTime*data.vehicleEnergyRate(2,car);
    vehicleAvailable(car) = now+emptyTime;
    batches(b).departure = depart;
    batches(b).returnTime = vehicleAvailable(car);
    batches(b).energy = energy;
    transportEnergy = transportEnergy+energy;
end
assert(column==n && all(seen), 'Batches do not cover all jobs exactly once.');
end
